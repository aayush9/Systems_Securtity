The program is a simple kernel module that captures 4 packets types used by NMAP utility: SYN, NULL, FIN, XMas.

SYN: nmap <ip> -sS
NULL: nmap <ip> -sN
FIN: nmap <ip> -sF
XMas: nmap <ip> -sX

Assumptions:
	Nothing as such, the module listens for incoming packets, and if their type matches with one of the 4 given above, it logs them.

Error Handling:
	Not Applicable

How to test:
	- Compile and insert module using makefule: $ make
	- Run nmap (with different flags for different type of packets), so the machine can listen to it.
	- View the system logs, using dmesg or /var/log/syslog

Inputs:
	sudo nmap -sF 10.211.55.25
	sudo nmap -sN 10.211.55.25
	sudo nmap -sS 10.211.55.25
	sudo nmap -sX 10.211.55.25

