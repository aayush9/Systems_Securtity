#include <linux/init.h>          
#include <linux/module.h>     
#include <linux/kernel.h>
#include <linux/syscalls.h>

#include <linux/skbuff.h>
#include <linux/if_packet.h>
#include <linux/ip.h>
#include <linux/netdevice.h>
#include <linux/if_ether.h>
#include <linux/inet.h>
#include <linux/icmp.h>
#include <linux/tcp.h>
#include <linux/in.h>
#include <linux/netfilter.h>
#include <linux/netfilter_ipv4.h>

struct packet_type pckt;
struct iphdr *iph;
struct tcphdr *tcph;

int recevie_and_log(struct sk_buff *skb, struct net_device *dev, struct packet_type *pt, struct net_device *orig_dev){
	if(!skb) return 0;
	iph = ip_hdr(skb);
	if(iph->protocol == IPPROTO_TCP) {
		// printk(KERN_INFO "%d %d %d %d     ", (int)tcph->fin, (int)tcph->psh, (int)tcph->urg, (int)tcph->syn);
		tcph = tcp_hdr(skb);
		if(tcph->fin && tcph->psh && tcph->urg)
			printk(KERN_INFO "TCP Packet captured!   Type: XMas");
		else if(tcph->fin)
			printk(KERN_INFO "TCP Packet captured!   Type: FIN");
		else if(tcph->syn)
			printk(KERN_INFO "TCP Packet captured!   Type: SYN");
		else
			printk(KERN_INFO "TCP Packet captured!   Type: NULL");
	}
	kfree_skb(skb);
	return 0;
}

static int my_init(void) {
	pckt.type = htons(ETH_P_IP); //
	pckt.dev = dev_get_by_name(&init_net,"enp0s5");
	pckt.func = recevie_and_log;

	dev_add_pack(&pckt);
	printk(KERN_ALERT "Init capturing device\n");
    return 0;
}

static void my_exit(void) {
	dev_remove_pack(&pckt);
    printk(KERN_ALERT "Exit capture device\n");
}

module_init(my_init);
module_exit(my_exit);