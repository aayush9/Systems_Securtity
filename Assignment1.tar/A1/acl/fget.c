#include "acl.c"


int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments!\n"),0;
	
	printf("User while starting: %u\n", getuid());

	int invoking_user = getuid();

	struct stat filestat;

	setuid(0);

	if(!stat(argv[1],&filestat) && S_ISREG(filestat.st_mode)){
		struct acl *a = (struct acl *) malloc(1005);
		if(getacl(invoking_user, argv[1], a) == -1) {
			printf("Error fetching metadata\n");
			goto end;
		}
		if(!check_permission(invoking_user,2,*a)){
			printf("You don't have read permissions!\n");
			goto end;
		}
		FILE *file = fopen(argv[1],"r");
		for(char line[205];fgets(line,205,file);printf("%s",line));
		fclose(file);
	} else if(!S_ISREG(filestat.st_mode)) 
		printf("It's a directory...\n");
	else 
		printf("File doesn't exist...\n");

	end:;
	setuid(invoking_user);

	printf("User while starting: %u\n", getuid());

	return 0;
}