#include "acl.c"

int main(){
	struct acl a;
	a.users[0] = 1001;
	a.permissions[0] = 7;
	a.length = 1;

	a.users[1] = 1002;
	a.permissions[1] = 1;
	a.length = 2;

	// for(int i=1;i<=4;++i){
	// 	a.users[i] = 1000+i;
	// 	a.permissions[i] = 4;
	// 	a.length++;
	// }

	char path[] = "./simple_slash/home/u1/test";
	setacl(a.users[0],path,a);

}