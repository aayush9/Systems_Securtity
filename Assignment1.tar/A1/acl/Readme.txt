Assumptions:
	- The ACLs only govern permissions for users, and not groups, group functionality is not required as per the prompt, and hence not implemented.
	- In the create_dir and fput command, the directory upto the parent has to exist for it to work, in case of relative paths (mkdir without the p flag).
	- Incase for a file, say u2 has write access, but no write access for the parent directory, u2 would be able to write to it, but if the file doesn't exist, wouldn't be able to create a new one. (Same for reading.)

Commands:
	- setacl: Takes input from user the user to give permissions to, what permissions in wrx format, and assigns them.
	-getacl: Prints the ACL struct to console, includes owner, and per user rwx permissions.

	- ls: Uses opendir and readdir to list the files, oner, size, date of last modification, and permissions the user has to them.
	- fput: Uses fopen to open the file in append mode and puts the given line into the file if user has w-access. If file doesn't exist it is created if user has w-access to parent dir.
	- fget: If the user has read access to file, irregardless of parent directories, the file is printing to the console.
	- create_dir: If user has w-access to parent directory, the new directory is created with acls of parent directory.
	- do_exec: Runs an executable owned by a given user as another user.

Error Handling:
	- Buffer overflow, using secure methods of input so as to control buffer size
	- Use of setuid to read files so as to bypass DAC.
	- Can't create things outside of simple_slash.

Inputs:
	In given inputs.sh file

Threat model:
	Some other user may be able to access resources owned by other people for which he/she has no access for, therefore the ACLs come into picture and deny operations in case the user doesn't have the particular permissions associated with the action he/she is trying to execute.
	The code is written carefully so that no user is able to exploit superuser permissions, while doing the operations. The files are still owned by the users themselves, and the fakeroot user setuid is only called during reading of the ACLs. Other operations are done as the normal user itself.

