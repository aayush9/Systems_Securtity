#include <stdio.h>
int main(int argc, char* argv[]){
	puts("Hello World!");
}