#include "acl.c"

int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments!\n"),0;
	printf("User while starting: %u\n", getuid());

	unsigned uid = geteuid();
	struct acl *a = (struct acl *) malloc(sizeof (struct acl));
	int status = getacl(uid, argv[1], a);
	if(status == -1){
		printf("Resource does not exist!\n");
		goto end;
	}

	if(a->users[0] != uid && uid != 0){
		printf("Cannot edit, you are not the owner!\n");
		goto end;
	}

	printf("Enter the user you wish to add/modify permissions for: ");
	char uname[10], *perm = (char*) malloc(5);
	fgets(uname,5,stdin);
	struct passwd *p;
	
	if((p=getpwnam(uname)) == NULL){
		printf("Invalid user!\n");
		goto end;
	}

	printf("Permissions for user (rwx): ");
	fgets(perm,5,stdin);
	int permissions = (perm[0]=='r')*4 + (perm[1]=='w')*2 + (perm[2]=='x');
	
	update_permissions((int) p->pw_uid,permissions,*a,argv[1]);
	end:;
	printf("User while extting: %u\n", getuid());

}

