#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <pwd.h>
#include <sys/stat.h>
#include <assert.h>
#include <errno.h>
#include <time.h>
#include <pwd.h>
#include <sys/wait.h>


char permission_codes[][4] = {
	"---",
	"--x",
	"-w-",
	"-wx",
	"r--",
	"r-x",
	"rw-",
	"rwx",
};

struct acl{
	int permissions[105];
	int users[105];
	int length;
};

int getacl(int uid, char *resource, struct acl *a){
	if(getxattr(resource,"user.custom_acl",a,1005) == -1)
		return -1;
	return 0;
}

int setacl(int uid, char *resource, struct acl a){
	if(setxattr(resource,"user.custom_acl",(void *)&a,1005,0) == -1)
		return -1;
	return 0;
}

int check_permission(int uid, int permission, struct acl a){
	for(int i=0;i<a.length;++i) if(a.users[i]==uid)
		if(a.permissions[i]>>permission&1) return 1;
	return uid==0;
}

int update_permissions(int uid, int permission, struct acl a, char *resource){
	for(int i=0;i<a.length;++i) if(a.users[i] == uid){
		a.permissions[i] = permission;
		goto permissions_set;
	}
	a.users[a.length] = uid;
	a.permissions[a.length] = permission;
	++a.length;
	permissions_set:;
	return setacl(uid,resource,a);
}


// int main(int argc, char *argv[]){}