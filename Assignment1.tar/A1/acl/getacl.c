#include "acl.c"

int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments!\n"),0;
	
	printf("User while starting: %u\n", getuid());

	unsigned uid = geteuid();
	struct acl *a = (struct acl *) malloc(1005);
	int status = getacl(uid, argv[1], a);
	if(status == -1){
		printf("Resource does not exist!\n");
		goto end;
	}
	if(!check_permission(uid, 2, *a)){
		printf("No read permissions!\n");
		goto end;
	}

	printf("Owner: %s\n", getpwuid(a->users[0])->pw_name);
	printf("Permissions:\n");
	for(int i=0;i<a->length;++i)
		printf(" %s : %s\n", getpwuid(a->users[i])->pw_name, permission_codes[a->permissions[i]]);

	end:;
	
	printf("User while exitting: %u\n", getuid());
}
