#include "acl.c"
int main(int argc, char *argv[]){
	printf("User while starting: %u\n", getuid());

	unsigned uid = geteuid();
	
	if(argc == 1){
		argv[1] = (char*) malloc(42);
		strcpy(argv[1],"./");
	} 

	struct acl *a = (struct acl *) malloc(1005);
	if(getacl(geteuid(), argv[1], a) == -1) {
		printf("Error fetching metadata\n");
		goto end;
	}
		
	int invoking_user = getuid();
	if(setuid(0)) {
		printf("Error being sudo\n");
		goto end;
	}
	if(!check_permission(invoking_user,2,*a)){
		printf("You don't have read permissions!\n");
		goto end;
	}

	struct dirent *ptr;
	DIR *dir = opendir(argv[1]); 
	char *arr[1005];
	int i;
	for (i=0; (ptr = readdir(dir))!=NULL; ++i){
		if(ptr->d_name[0] == '.') continue;
		char *fname = (char*) malloc(1024); 
		if(argv[1]){
			strcat(fname,argv[1]);
			if(fname[strlen(fname)-1]!='/') fname[strlen(fname)] = '/';
		}
		strcat(fname,ptr->d_name);
		struct acl *a = (struct acl *) malloc(1005);
		if(getacl(uid, fname, a) == -1) continue;
		// printf("%s %s\n", ptr->d_name, fname);
		struct stat st; stat(fname,&st);
		char mtime[42];
		struct tm* timeinfo;
		strftime(mtime,sizeof mtime, "%b %d %H:%M", localtime(&st.st_mtime));
		int p = check_permission(invoking_user,2,*a)*4 + check_permission(invoking_user,1,*a)*2 + check_permission(invoking_user,0,*a);
		printf("%s  %s  %s  %zd   %s\n",ptr->d_name,getpwuid(a->users[0])->pw_name,permission_codes[p], st.st_size, mtime);
	}
	closedir(dir);

	end:;
	setuid(invoking_user);
	printf("User while exitting: %u\n", getuid());
}