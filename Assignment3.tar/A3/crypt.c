#include <openssl/ssl.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>
#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/err.h>
#include <openssl/err.h>

#include "acl.c"

//Reference: https://medium.com/@amit.kulkarni/encrypting-decrypting-a-file-using-openssl-evp-b26e0e4d28d4

typedef struct _cipher_params_t{
    unsigned char *key;
    unsigned char *iv;
    unsigned int encrypt;
    const EVP_CIPHER *cipher_type;
}cipher_params_t;

void file_encrypt_decrypt(cipher_params_t *params, FILE *ifp, FILE *ofp){
    int evp_blk_sz = EVP_CIPHER_block_size(EVP_aes_256_cbc()), bytes_read, out_len;
    unsigned char in_buf[256], out_buf[256+evp_blk_sz];
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();

    EVP_CipherInit_ex(ctx, params->cipher_type, NULL, NULL, NULL, params->encrypt);
    EVP_CipherInit_ex(ctx, NULL, NULL, params->key, params->iv, params->encrypt);

    do{
        bytes_read = fread(in_buf, sizeof(unsigned char), 256, ifp);
        EVP_CipherUpdate(ctx, out_buf, &out_len, in_buf, bytes_read);
        fwrite(out_buf, sizeof(unsigned char), out_len, ofp);
    } while(bytes_read >= 256);

    EVP_CipherFinal_ex(ctx, out_buf, &out_len);
    fwrite(out_buf, sizeof(unsigned char), out_len, ofp);
    EVP_CIPHER_CTX_cleanup(ctx);
}

int encrypt_decrypt(char *path, int encrypt){
	struct acl *dir_acl = (struct acl *) malloc(1005);
	if(getacl(0, path, dir_acl) == -1)
		return -1;

	cipher_params_t *params = (cipher_params_t *)malloc(sizeof(cipher_params_t));
	if(!params) return 2;

	unsigned char key[32];
    unsigned char iv[16];

    FILE *shadow; 
    shadow = fopen("/etc/shadow","r");
    char line[1024]; int len = 0;
    char user[105]; 
    struct passwd *u_info;
    u_info = getpwuid(dir_acl->users[0]);
    strcpy(user, u_info->pw_name);

    memset(key, 0 ,sizeof key);
    memset(iv, 0 ,sizeof iv);

    while(fgets(line, 1005, (FILE*) shadow)) {
    	char *now = line;
        char* uname = __strtok_r(now, ":", &now);
        if(strcmp(uname, user)) continue;
        char* hash = __strtok_r(now, ":", &now);
        hash += 10;
        for(int i=0;i<32;++i) key[i] = hash[i];
        hash += 32;
        for(int i=0;i<16;++i) iv[i] = hash[i];
    }
    fclose(shadow);

    params->key = key;
    params->iv = iv;

    params->encrypt = encrypt;

    params->cipher_type = EVP_aes_256_cbc();

    FILE *src, *dst;

    char *tmp_path = (char *)malloc(1005);
    sprintf(tmp_path,"%s.tmp", path);


    if(!(src = fopen(path,"r")) || !(dst = fopen(tmp_path,"w")))
    	return 3;

    char c;
    do { 
    	c = fgetc(src);
    	if(c!=EOF) 
    		fputc(c, dst); 
    } while(c != EOF);

    fclose(dst);
    fclose(src);

    if(!(src = fopen(tmp_path,"rb")) || !(dst = fopen(path,"wb")))
    	return 3;

    file_encrypt_decrypt(params, src, dst);

    fclose(src);
    fclose(dst);

    remove(tmp_path);
    return 0;
}

int sign(char* path, int verify){
	struct acl *dir_acl = (struct acl *) malloc(1005);
	if(getacl(0, path, dir_acl) == -1)
		return -1;
	cipher_params_t *params = (cipher_params_t *)malloc(sizeof(cipher_params_t));
	if(!params) return 2;

	unsigned char key[32];
    unsigned char iv[16];

    FILE *shadow; 
    shadow = fopen("/etc/shadow","r");
    char line[1024]; int len = 0;
    char user[105]; 
    struct passwd *u_info;
    u_info = getpwuid(dir_acl->users[0]);
    strcpy(user, u_info->pw_name);

    memset(key, 0 ,sizeof key);
    memset(iv, 0 ,sizeof iv);

    while(fgets(line, 1005, (FILE*) shadow)) {
    	char *now = line;
        char* uname = __strtok_r(now, ":", &now);
        if(strcmp(uname, user)) continue;
        char* hash = __strtok_r(now, ":", &now);
        hash += 10;
        for(int i=0;i<32;++i) key[i] = hash[i];
        hash += 32;
        for(int i=0;i<16;++i) iv[i] = hash[i];
    }
    fclose(shadow);


    char *tmp_path = (char *)malloc(1005);
    sprintf(tmp_path,"%s.sign", path);

    FILE *src = fopen(path, "rb");
    char data[1024];
    memset(data,0,sizeof data);
    for(int i=0;;++i){
    	char c = fgetc(src);
    	data[i] = c;
    	if(c == EOF) break;
    }
    fclose(src);

    char *signature = HMAC(EVP_sha1(), key, 32, data, strlen(data), NULL, NULL);
    if(!verify){
	    src = fopen(tmp_path, "wb");
	    for(int i=0;i<1024;++i){
	    	fputc(signature[i],src);
	    }
	    fclose(src);
	} else {
		struct stat filestat;
		int rvalue = 0;
		if(!stat(tmp_path, &filestat)){
			src = fopen(tmp_path, "rb");
			for(int i=0;i<1024;++i){
				char c = fgetc(src);
				if(c!=signature[i])
					rvalue = 1;
			}
			fclose(src);		
		}
		return rvalue;	
	}
	return 0;
}

