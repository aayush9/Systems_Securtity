Reference: https://medium.com/@amit.kulkarni/encrypting-decrypting-a-file-using-openssl-evp-b26e0e4d28d4

Assumptions:
	- Incase for a file, say u2 has write access, but no write access for the parent directory, u2 would be able to write to it, but if the file doesn't exist, wouldn't be able to create a new one. (Same for reading.)
	- File and extension means that abc.txt would become abc.txt.sign for sign file. Since it would avoid cases when file name doesn't have a .txt or similar extension already.

Commands:
	- fput_encrypt: Reads the file, decrypts it, adds the user input to it and encrypts again.
	-fget_decrypt: Dycrypts the file into tmp file, and prints to console, then encrypts again.
	- fsign: Used the HMAC function, and saved to the corresponding .sign file.
	- fverify: Reads the .sign file if present, and verifies the signature against the generated HMAC. Exits gracefully if match, else throws error and says not match.

Error Handling:
	- Buffer overflow, using secure methods of input so as to control buffer size
	- Use of setuid to read files so as to bypass DAC.
	- Can't create things outside of simple_slash.

Inputs:
	In given inputs.sh file
	For fsign, fverify. Sign the file, then make changes using sudo bash -c "echo lol >> simple_slash/home/u1/lol.txt ", the signature won't match and would get mismatch error.


Expected outcomes:
	- fput_encrypt: should be able to append the file if you have write permission. It should appear encrypted.
	- fget_decrypt: should be able to read the file if you have read permission. It should appear plain text. If sign file present, it also has to be matched.
	- fsign: If RW access, should be able to generate a .sign thing in same directory. Would overwrite file of same name if needed.
	- fverify: Matches the sign file with the encrypted file.

