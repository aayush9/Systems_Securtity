sudo -u u1 ./ls simple_slash/
sudo -u u1 ./ls
cd simple_slash
sudo -u u2 ../ls home
cd ..
sudo -u u2 ./fget simple_slash/home/u1/newdir/a.txt
sudo -u u1 ./fget simple_slash/home/u1/newdir/a.txt
sudo -u u1 ./create_dir simple_slash/home/new
sudo -u u1 ./doexec simple_slash/home/u1/test
sudo -u u2 ./doexec simple_slash/home/u1/test
sudo -u u3 ./doexec simple_slash/home/u1/test
sudo -u u3 ./doexec simple_slash/home/u1/test.txt
sudo -u u1 ./doexec simple_slash/home/u1/test.txt
sudo -u u3 ./doexec simple_slash/home/u1/test.tx
