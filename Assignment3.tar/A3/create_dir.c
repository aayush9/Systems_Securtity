#include "acl.c"


char *get_last_token(char *path){
	char *file_name = (char*) malloc(105);
	int last_slash=0;
	for(int i=0;path[i];++i) if(path[i]=='/') last_slash = i+1;
	strcpy(file_name,path+last_slash);
	for(int i=last_slash;path[i];path[i++]=0);
	return file_name;
}

int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments!\n"),0;

	printf("User while starting: %u\n", getuid());

	int invoking_user = getuid();

	struct stat st;
	if(!stat(argv[1],&st)) {
		printf("Directory exists\n");
		goto end;
	}
	char *path = (char*)malloc(505);
	strcpy(path,"./");
	strcat(path,argv[1]);
	get_last_token(path);

	struct acl *dir_acl = (struct acl *) malloc(1005);
	if(getacl(invoking_user, path, dir_acl) == -1) {
		printf("Error fetching metadata\n");
		goto end;
	}
	if(!check_permission(invoking_user,1,*dir_acl)){
		printf("No write permissions on directory\n");
		goto end;
	}

	mkdir(argv[1],0740);

	if(setacl(invoking_user,argv[1],*dir_acl))
		printf("Problem setting acls\n");
	else
		printf("Directory created with default acl\n");


	end:;
	printf("User while exitting: %u\n", getuid());
}