#include "acl.c"
char *get_last_token(char *path){
	char *file_name = (char*) malloc(105);
	int last_slash=0;
	for(int i=0;path[i];++i) if(path[i]=='/') last_slash = i+1;
	strcpy(file_name,path+last_slash);
	for(int i=last_slash;path[i];path[i++]=0);
	return file_name;
}

int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments!\n"),0;

	printf("User while starting: %u\n", getuid());
	int invoking_user = getuid();

	struct stat filestat,dirstat;

	setuid(0);

	if(stat(argv[1],&filestat)){

		char *path = (char*)malloc(505);
		strcpy(path,"./");
		strcat(path,argv[1]);
		get_last_token(path);

		if(stat(path,&dirstat)){
			printf("No such directory\n");
			goto end;
		}

		struct acl *dir_acl = (struct acl *) malloc(1005);
		if(getacl(invoking_user, path, dir_acl) == -1) {
			printf("Error fetching metadata\n");
			goto end;
		}
		if(!check_permission(invoking_user,1,*dir_acl)){
			printf("No write permissions on directory\n");
			goto end;
		}

		FILE *file = fopen(argv[1],"w");
		fclose(file);

		struct acl a;
		a.users[0] = invoking_user;
		a.permissions[0] = 7;
		a.length = 1;

		if(setacl(invoking_user,argv[1],a))
			printf("Problem setting acls\n");
		else
			printf("File created with default acl\n");
	}
	struct acl *a = (struct acl *) malloc(1005);
	if(getacl(invoking_user, argv[1], a) == -1) {
		printf("Error fetching metadata\n");
		goto end;
	}

	if(!check_permission(invoking_user,1,*a)){
		printf("Cannot edit, no write permissions!\n");
		goto end;
	}


	FILE *file = fopen(argv[1],"a");
	char message[1024];
	printf(": "); fgets(message,1024,stdin);
	fprintf(file,"%s\n",message);
	fclose(file);

	end:;
	setuid(invoking_user);
	printf("User while exitting: %u\n", getuid());

}
