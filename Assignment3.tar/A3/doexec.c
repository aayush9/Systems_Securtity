#include "acl.c"

int main(int argc, char *argv[]){
	if(argc != 2)
		return printf("Invalid number of arguments\n"),0;

	printf("User while starting: %u\n", getuid());

	int invoking_user = getuid();

	struct stat filestat;
	setuid(0);

	if(!stat(argv[1],&filestat) && filestat.st_mode&S_IXUSR){
		struct acl *a = (struct acl *) malloc(1005);
		if(getacl(invoking_user, argv[1], a) == -1) {
			printf("Error fetching metadata\n");
			goto end;
		}
		if(!check_permission(invoking_user,0,*a)){
			printf("No execute permission\n");
			goto end;
		}

		char *args[105];
		for(int i=1;i<argc;++i){
			args[i-1] = (char *) malloc(105);
			strcpy(args[i-1],argv[i]);
			args[i] = NULL; 
		}

		if(!fork()){
			int ret = execve(argv[1],args,NULL);
			if(ret) printf("Invalid Command!\n");
			exit(0);
		}
		else{
			wait(NULL);
		}
	}
	else if(stat(argv[1],&filestat))
		printf("No such file\n");
	else 
		printf("File not an executable\n");

	end:;
	setuid(invoking_user);

	printf("User while starting: %u\n", getuid());

	return 0;

}